"""
Main package for aiverify general corruptions plugin.
"""
