"""
Main package for partial dependence plot for classification plugin.
"""
