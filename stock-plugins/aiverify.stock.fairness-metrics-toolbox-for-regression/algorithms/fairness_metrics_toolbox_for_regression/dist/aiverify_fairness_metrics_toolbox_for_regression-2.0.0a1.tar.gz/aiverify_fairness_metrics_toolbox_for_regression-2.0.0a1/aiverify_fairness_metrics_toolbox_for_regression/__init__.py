"""
Main package for Fairness metrics toolbox for regression plugin.
"""
