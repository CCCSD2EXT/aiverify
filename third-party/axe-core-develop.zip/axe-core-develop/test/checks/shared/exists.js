describe('exists', function () {
  'use strict';

  it('should return undefined', function () {
    assert.isUndefined(checks.exists.evaluate());
  });
});
