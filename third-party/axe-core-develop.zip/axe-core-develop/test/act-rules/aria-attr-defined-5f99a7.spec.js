require('./act-runner.js')({
  id: '5f99a7',
  title: 'ARIA attribute is defined in WAI-ARIA',
  axeRules: ['aria-valid-attr']
});
