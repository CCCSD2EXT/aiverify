require('./act-runner.js')({
  id: 'bf051a',
  title: 'HTML page lang attribute has valid language tag',
  axeRules: ['html-lang-valid']
});
