require('./act-runner.js')({
  id: 'afw4f7',
  title: 'Text has minimum contrast',
  axeRules: ['color-contrast']
});
