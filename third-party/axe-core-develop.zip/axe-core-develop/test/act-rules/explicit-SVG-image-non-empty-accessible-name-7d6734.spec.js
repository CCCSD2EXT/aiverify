require('./act-runner.js')({
  id: '7d6734',
  title: 'svg element with explicit role has non-empty accessible name',
  axeRules: ['svg-img-alt']
});
