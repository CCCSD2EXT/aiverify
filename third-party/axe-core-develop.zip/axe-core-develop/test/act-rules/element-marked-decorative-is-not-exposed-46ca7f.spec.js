require('./act-runner.js')({
  id: '46ca7f',
  title: 'Element marked as decorative is not exposed',
  axeRules: ['presentation-role-conflict']
});
