require('./act-runner.js')({
  id: '6cfa84',
  title:
    'Element with aria-hidden has no content in sequential focus navigation',
  axeRules: ['aria-hidden-focus']
});
