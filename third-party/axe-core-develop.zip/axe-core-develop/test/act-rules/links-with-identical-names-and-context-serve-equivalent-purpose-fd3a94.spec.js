require('./act-runner.js')({
  id: 'fd3a94',
  title:
    'Links with identical accessible names and context serve equivalent purpose',
  axeRules: ['identical-links-same-purpose']
});
