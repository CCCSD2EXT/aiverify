require('./act-runner.js')({
  id: '73f2c2',
  title: 'autocomplete attribute has valid value',
  axeRules: ['autocomplete-valid']
});
