require('./act-runner.js')({
  id: 'bc4a75',
  title: 'ARIA required owned elements',
  axeRules: ['aria-required-children']
});
