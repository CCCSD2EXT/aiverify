require('./act-runner.js')({
  id: '23a2a8',
  title: 'Image has non-empty accessible name',
  axeRules: ['image-alt', 'role-img-alt']
});
