require('./act-runner.js')({
  id: 'ffd0e9',
  title: 'Heading has non-empty accessible name',
  axeRules: ['empty-heading']
});
