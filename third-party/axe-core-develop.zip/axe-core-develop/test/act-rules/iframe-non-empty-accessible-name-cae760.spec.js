require('./act-runner.js')({
  id: 'cae760',
  title: 'Iframe element has non-empty accessible name',
  axeRules: ['frame-title']
});
