require('./act-runner.js')({
  id: '78fd32',
  title: 'Line height in style attributes is not !important',
  axeRules: ['avoid-inline-spacing']
});
