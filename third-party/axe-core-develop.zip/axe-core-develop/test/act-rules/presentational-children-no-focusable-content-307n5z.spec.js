require('./act-runner.js')({
  id: '307n5z',
  title: 'Element with presentational children has no focusable content',
  axeRules: ['nested-interactive']
});
