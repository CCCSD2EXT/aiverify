require('./act-runner.js')({
  id: '4e8ab6',
  title: 'Element with role attribute has required states and properties',
  axeRules: ['aria-required-attr']
});
