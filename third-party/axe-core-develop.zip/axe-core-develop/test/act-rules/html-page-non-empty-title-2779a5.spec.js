require('./act-runner.js')({
  id: '2779a5',
  title: 'HTML page has non-empty title',
  axeRules: ['document-title']
});
