require('./act-runner.js')({
  id: '8fc3b6',
  title:
    'Object element rendering non-text content has non-empty accessible name',
  axeRules: ['object-alt']
});
