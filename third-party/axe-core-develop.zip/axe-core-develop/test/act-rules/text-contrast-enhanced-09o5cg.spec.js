require('./act-runner.js')({
  id: '09o5cg',
  title: 'Text has enhanced contrast',
  axeRules: ['color-contrast', 'color-contrast-enhanced']
});
