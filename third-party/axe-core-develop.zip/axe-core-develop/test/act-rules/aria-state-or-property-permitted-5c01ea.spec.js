require('./act-runner.js')({
  id: '5c01ea',
  title: 'ARIA state or property is permitted',
  axeRules: ['aria-allowed-attr', 'aria-prohibited-attr']
});
