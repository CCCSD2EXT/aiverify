require('./act-runner.js')({
  id: '5b7ae0',
  title: 'HTML page lang and xml:lang attributes have matching values',
  axeRules: ['html-xml-lang-mismatch']
});
