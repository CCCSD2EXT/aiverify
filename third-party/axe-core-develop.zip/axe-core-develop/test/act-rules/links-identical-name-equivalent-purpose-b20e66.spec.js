require('./act-runner.js')({
  id: 'b20e66',
  title: 'Links with identical accessible names have equivalent purpose',
  axeRules: ['identical-links-same-purpose']
});
