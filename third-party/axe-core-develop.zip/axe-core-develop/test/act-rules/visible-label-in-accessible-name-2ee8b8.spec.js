require('./act-runner.js')({
  id: '2ee8b8',
  title: 'Visible label is part of accessible name',
  axeRules: ['label-content-name-mismatch']
});
