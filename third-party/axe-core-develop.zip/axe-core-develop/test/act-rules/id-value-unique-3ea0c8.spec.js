require('./act-runner.js')({
  id: '3ea0c8',
  title: 'id attribute value is unique',
  axeRules: ['duplicate-id', 'duplicate-id-aria', 'duplicate-id-active']
});
