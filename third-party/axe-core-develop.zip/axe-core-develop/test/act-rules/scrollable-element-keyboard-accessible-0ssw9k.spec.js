require('./act-runner.js')({
  id: '0ssw9k',
  title: 'Scrollable element is keyboard accessible',
  axeRules: ['scrollable-region-focusable']
});
