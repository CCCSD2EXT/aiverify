require('./act-runner.js')({
  id: '59796f',
  title: 'Image button has non-empty accessible name',
  axeRules: ['input-image-alt']
});
