require('./act-runner.js')({
  id: 'b5c3f8',
  title: 'HTML page has lang attribute',
  axeRules: ['html-has-lang']
});
