require('./act-runner.js')({
  id: 'a25f45',
  title:
    'Headers attribute specified on a cell refers to cells in the same table element',
  axeRules: ['td-headers-attr']
});
