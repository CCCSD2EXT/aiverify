require('./act-runner.js')({
  id: 'de46e4',
  title: 'Element with lang attribute has valid language tag',
  axeRules: ['valid-lang']
});
