require('./act-runner.js')({
  id: 'b33eff',
  title:
    'Orientation of the page is not restricted using CSS transform property',
  axeRules: ['css-orientation-lock']
});
