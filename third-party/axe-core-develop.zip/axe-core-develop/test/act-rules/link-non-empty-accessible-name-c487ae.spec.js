require('./act-runner.js')({
  id: 'c487ae',
  title: 'Link has non-empty accessible name',
  axeRules: ['link-name', 'area-alt']
});
