require('./act-runner.js')({
  id: '97a4e1',
  title: 'Button has non-empty accessible name',
  axeRules: ['button-name', 'aria-command-name']
});
