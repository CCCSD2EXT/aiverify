require('./act-runner.js')({
  id: 'm6b1q3',
  title: 'Menuitem has non-empty accessible name',
  axeRules: ['aria-command-name', 'button-name', 'link-name']
});
