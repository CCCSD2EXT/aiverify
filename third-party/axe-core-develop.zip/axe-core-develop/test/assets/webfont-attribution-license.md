# Webfont Attribution and Licenses

## FiraCode-Regular:

https://github.com/tonsky/FiraCode
License: SIL Open Font License 1.1

## Ligature Symbols

https://github.com/kudakurage/LigatureSymbols
License: SIL Open Font License 1.1

## Material Icons

https://google.github.io/material-design-icons
License: Apache License Version 2.0

## Roboto

https://fonts.google.com/specimen/Roboto
License: Apache License, Version 2.0
